const express = require('express')
const bodyParser = require('body-parser')

const store = require('./store')

const app = express()
app.use(express.static('public'))
app.use(bodyParser.json())
app.post('/createEvent', (req, res) => {
  store
    .createEvent({
      title: req.body.title,
      description: req.body.description,
      location: req.body.location,
      date: req.body.date,
      image: req.body.image
    })
    .then(() => {
      res.addHeader('Access-Control-Allow-Origin: *')
      res.sendStatus(200)
    })
})

// app.listen(8080, () => {
//   console.log('Server running on http://localhost:8080')
// })