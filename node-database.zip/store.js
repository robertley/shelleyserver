var mysql = require('mysql');

var connection = mysql.createConnection({
  host     : 'shelleysitedb.ccrpnpe8qc1r.us-west-2.rds.amazonaws.com',
  user     : 'shelley',
  password : 'shelleysite',
  port     : 3306
});

connection.connect(function(err) {
  if (err) {
    console.error('Database connection failed: ' + err.stack);
    return;
  }

  console.log('Connected to database.');
});

module.exports = {
  createEvent ({ title, description, location, date, image }) {
    console.log(`${title} , ${description} , ${location} , ${date}, ${image}`)
    return Promise.resolve()
  }
}

connection.end();